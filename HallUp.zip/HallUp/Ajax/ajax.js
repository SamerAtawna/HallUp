var eventTables;
function showSuccess(){
    $('.alert').slideDown();
    setTimeout(() => {
     $('.alert').slideUp();
    }, 3000);
   }


    function updateData(){
        husband =  $("#husband").val();
        date =   $("#eventdate").val();
        wife=    $("#wife").val();
        phone=    $("#phone").val();
        eventid= selectedEvent;
$.ajax({
    method:"POST",
    url: "../php/updateEvent.php",
    data:{
        'husband' :husband,
        'wife':wife,
        'date':date,
        'phone':phone,
        'evid': eventid

    },
    success:(data)=>{
        console.log(data);
        showSuccess();
    }
})
}



function createEvent1(){
    husband =  $("#husbandc").val();
    date =   $("#eventdatec").val();
    wife=    $("#wifec").val();
    phone=    $("#phonec").val();
    hallid =  $("#selectedHallId").val();
$.ajax({
method:"POST",
url: "../php/createEvent.php",
data:{
    'husbandc' :husband,
    'wifec':wife,
    'datec':date,
    'phonec':phone,
    'hallidc': hallid

},
success:(data)=>{
    console.log(data);
    showSuccess();
}
})
}


function delEvent(evid){
    eventid = evid;
    $.ajax({
method:"POST",
url: "../php/deleteEvent.php",
data:{
    'evid' :eventid
},
success:(data)=>{
    console.log(data);
    showSuccess();
        }
    })
}

function delMeal(mealid){
    mealId =mealid ;
    $.ajax({
method:"POST",
url: "../php/deleteMeal.php",
data:{
    'mealId' :mealId
},
success:(data)=>{
    console.log(data);
    showSuccess();
        }
    })
}
function addMeal(){
    eventid = $("#eventidselected").val();
    mealName = $("#mealname").val();
    mealc = $("#mealcat").val();
    $.ajax({
method:"POST",
url: "../php/addMeal.php",
data:{
    'eventId' :eventid,
    'mname':mealName,
    'mealcat': mealc
},
success:(data)=>{
    console.log(data);
    showSuccess();
        }
    })
}

function getCounters(){
    selectedEventId1 = $("#selectedEventId").val(); 
    $.ajax({
        method:"POST",
url: "../php/getCounter.php",
data:{
    'selectedEventId': selectedEventId1
},
success:(data)=>{
console.log(data);
    let counter = JSON.parse(data);
    console.log(counter);
  $(".arriveNumber").html(counter.IsApproved);
  $(".maybeNumber").html(counter.Maybe);
  $(".notNumber").html(counter.IsNotApproved);
  $(".TotalNumber").html(counter.Total);
        }
    })
}


function updateGuest(){
    name =  $("#gname").val();
    phone =   $("#gphone").val();
    arrive=    $("#garrive").val();
    guestid= selectedGuest;
    console.log(name, phone, arrive, guestid);
$.ajax({
method:"POST",
url: "../php/updateGuest.php",
data:{
    'guestid':guestid,
    'name' :name,
    'phone':phone,
    'arrive':arrive,

},
success:(data)=>{
    console.log(data);
    showSuccess();
}
})
}

function createGuest(){
    name = $("#agname").val();
    phone = $("#agphone").val();
    arrivals = $("#agarrivenum").val();
    arrive = $("#agarrive").val();
   evenid =  $("#selectedEventId").val();
    $.ajax({
method:"POST",
url: "../php/createGuest.php",
data:{
    'name' :name,
    'phone':phone,
    'arrivals': arrivals,
    'arrive':arrive,
    'EventID':evenid
},
success:(data)=>{
    console.log(data);

        }
    })
}


function deleteGuest(gid){
    $.ajax({
method:"POST",
url: "../php/deleteGuest.php",
data:{
    'guestId' :gid
},
success:(data)=>{
    console.log(data);
    showSuccess();
        }
    })
}


function createMenu(){
    data = JSON.stringify(selectedMeals);
    eventid = $("#selectedEventId").val();
    $.ajax({
        method:"POST",
        url: "../php/createMenu.php",
        data:{
            'menu' :data,
            'eventid':eventid
        },
        success:(data)=>{
            console.log(data);
        
                }
            })
    
}

function deleteTable(tbid){
    eventid = $("#eventid").val();
    $.ajax({
method:"POST",
url: "../php/deleteTable.php",
data:{
    'tableid' :tbid,
    'eventid': eventid
},
success:(data)=>{
        $(".tables-area").html(data);
        }
    })
}


function createTable(){

    eventid = $("#eventid").val();
    tablename= $("#tableName").val();
    tablechairs=$("#tableChairs").val();
    $.ajax({
        method:"POST",
        url: "../php/createTable.php",
   
        data:{
            'tablename' :tablename ,
            'tablechairs':tablechairs,
            'eventid': eventid
        },
        success:(data)=>{
               $(".tables-area").html(data);
        
                }
            })
    
}


function getTables(){
    evid = $("#selectedEventId").val();
    $.ajax({
        datatype:"json",
method:"GET",
url: "../php/getTables.php",
data:{
    'eventid' :evid
},
success:(data)=>{

    eventTables = JSON.parse(data);
        }
    })
}


function updateChair(id){
    tablename =  $("#guest"+id).val();
    guestid =  id;


$.ajax({
method:"POST",
url: "../php/updateChair.php",
data:{
    'tablename' :tablename,
    'guestid': guestid

},
success:(data)=>{
    console.log(data);
getTablesCounters();
   
}
})
}
function getTablesCounters(){
    evid = $("#selectedEventId").val();
    $.ajax({
        datatype:"json",
method:"POST",
url: "../php/tableCounters.php",
data:{
    'eventid' :evid
},
success:(data)=>{

    $(".tablesData").html(data);
        }
    })
}

