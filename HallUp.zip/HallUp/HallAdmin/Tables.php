<link rel="stylesheet" href="table.css" type="text/css">
<?php
 session_start();
require "../cdn.html";
require "../AdminNav/Nav.php";
?>
<?php 
echo "<input type='hidden' value='{$_POST["eventid"]}' id=eventid>";
?>
<div class="container">
<h3>  שולחנות עבור האירוע של <?php echo $_POST["husband"]." ו".$_POST["wife"] ?></h3>
        <div class="tables-container">
                    <div class="tables-title heavy-rain-gradient">
                        <?php 
                        $sql = "SELECT  count(Name) as cnt FROM Tables where EventID={$_POST["eventid"]}";

                        if($result = mysqli_query($con,$sql))
                        {
               
                        
                          while($row = mysqli_fetch_assoc($result))
                          {
                              echo "<div class='tablescount'><span class=\"badge badge-info ml-2\">{$row["cnt"]} </span> סהכ שולחנות</div>";
                          }
                        }
                        $sql1 = "SELECT  sum(Chairs) as cnt FROM Tables  where EventID={$_POST["eventid"]}";
                        if($result = mysqli_query($con,$sql1))
                        {
               
                        
                          while($row = mysqli_fetch_assoc($result))
                          {
                              echo "<div class='tablescount'><span class=\"badge badge-info ml-2\">{$row["cnt"]} </span> סהכ כסאות</div>";
                          }
                        }
                        ?>
                    </div>
                    <div class="tables-buttons heavy-rain-gradient">
                        <button class="btn btn-primary"  data-toggle='modal' data-target='#tableModal' >  הוספת שולחן +</div>


                        <div class="tables-area cloudy-knoxville-gradient">
                    
                            <?php 
                                    $sql = "SELECT  * FROM Tables where EventID={$_POST["eventid"]}";

                                    if($result = mysqli_query($con,$sql))
                                    {

                                    
                                    while($row = mysqli_fetch_assoc($result))
                                    {
                                        echo "<div class=\"table night-fade-gradient\">";
                                        echo "<input type='hidden' id='tableid' value='{$row["TableID"]}'>";
                                        echo "  <div class=\"table-name\">{$row["Name"]}</div>";
                                        echo "<div class=\"table-chairs\">{$row["Chairs"]}</div>";
                                        echo "<div class=\"table-buttons\">";
                                        echo "<div class=\"btn-group\" role=\"group\" aria-label=\"Basic example\">";
                                        echo " <button type=\"button\" class=\"btn btn-primary btn-sm\">שינוי</button>";
                                        echo " <button type=\"button\" class=\"btn btn-danger btn-sm\" onclick='deleteTable({$row["TableID"]})'>מחיקה</button>";
                                        echo "</div></div></div>";
                                    }
                            }
                            
                            ?>

                            </div>
                        </div>
  
    
    
        </div>
</div>

<!-- Create table Modal -->
<div class="modal fade" id="tableModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">הוספת שולחן</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <span> שם שולחן</span>     <input type=text size="20" class="form-control"  id="tableName">
      <span>מספר כסאות</span>  <div class="def-number-input number-input">
  <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" class="minus"></button>
  <input class="quantity" id="tableChairs" min="0" name="quantity" value="1" type="number">
  <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus"></button>
</div>

        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ביטול</button>
        <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="createTable()">שמירה</button>
      </div>
    </div>
  </div>
</div>