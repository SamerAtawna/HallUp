
<?php
 session_start();
require "../cdn.html";
require "../AdminNav/Nav.php";
echo  "<input type='hidden' id='selectedHallId' value='".$_SESSION["HallId"]."'>";
?>
<div class="alert alert-success" role="alert">
  הפעולה בוצעה בהצלחה
</div>
<div class="container">

<?php
$sql = "SELECT * FROM Events where HallId=".$_SESSION["HallId"];

if($result = mysqli_query($con,$sql))
{
    echo "<table id='eventTable' class='table' style='width:100%'>";
        echo "<thead>";
            echo "<tr>";
            echo "<th>מזהה אירוע</th>";
            echo "<th>חתן</th>";
            echo "<th>כלה</th>";
            echo "<th>תאריך</th>";
            echo "<th>טלפון</th>";
            echo "<th> שנה פרטים</th>";
            echo "<th> שולחנות</th>";
            echo "<th>שנה תפריט</th>";
            echo "<th>מחיקה</th>";
            echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
  

  while($row = mysqli_fetch_assoc($result))
  {
    echo "<tr>";
      echo "<td>".$row['EventID']."</td>";
      echo "<td>".$row['Husband']."</td>";
      echo "<td>".$row['Wife']."</td>";
      echo "<td>".$row['Date']."</td>";
      echo "<td>".$row['Phone']."</td>";
      echo "<td><input type=button onclick=\"changeDetails('".$row['EventID']."','".$row['Husband']."','".$row['Wife']."','".$row['Date']."','".$row['Phone']."')\" value='שינוי' class='btn btn-primary btn-sm'  data-toggle='modal' data-target='#exampleModal'></td>";
      echo "<td><form action=\"Tables.php\" method='post'><input type=hidden value=".$row['EventID']." name='eventid'><input type=hidden value=".$row['Husband']." name='husband'><input type=hidden value=".$row['Wife']." name='wife'><input type=submit value='שולחנות' class='btn btn-primary btn-sm'></form></td>";
      echo "<td><form action=\"editMeals.php\" method='post'><input type=hidden value=".$row['EventID']." name='eventid'><input type=hidden value=".$row['Husband']." name='husband'><input type=hidden value=".$row['Wife']." name='wife'><input type=submit value='שנה תפריט' class='btn btn-primary btn-sm'></form></td>";
      echo "<td><input type=button onclick=\"delEvent('".$row['EventID']."')\" value='מחיקה' class='btn btn-danger btn-sm'></td>";
      echo "</tr>";
  }

echo "</tbody>";
echo "</table>";

}
?>
<button type="button" class="btn btn-success" data-dismiss="modal" onclick=""  data-toggle='modal' data-target='#createModal'>יצירת אירוע</button>
<button type="button" class="btn btn-success" onclick="sendSMS()">SMS</button>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">עדכון פרטים</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <span>חתן</span>     <input type=text size="20" class="form-control"  id="husband">
      <span>כלה</span>  <input type=text size="20"  class="form-control" id="wife">
      <span>תאריך</span>  <input size="16" type="text" id="eventdate" value="" readonly class="form_datetime">
      <span>טלפון</span>  <input type=text size="20"  class="form-control" id="phone">
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ביטול</button>
        <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="updateData()">שמירה</button>
      </div>
    </div>
  </div>
</div>
<!-- Create Modal -->
<div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">יצירת אירוע</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <span>חתן</span>     <input type=text size="20" class="form-control"  id="husbandc">
      <span>כלה</span>  <input type=text size="20"  class="form-control" id="wifec">
      <span>תאריך</span>  <input size="16" type="text" id="eventdatec" value="" readonly class="form_datetime">
      <span>טלפון</span>  <input type=text size="20"  class="form-control" id="phonec">
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ביטול</button>
        <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="createEvent1()">שמירה</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
    $(".form_datetime").datetimepicker({format: 'yyyy-mm-dd hh:ii'});
</script>   
<script>
var selectedEvent ;
function showSuccess(){
 $('.alert').slideDown();
 setTimeout(() => {
  $('.alert').slideUp();
 }, 3000);
}

function changeDetails(id, husband, wife, date, phone){
    selectedEvent = id;
    $("#husband").val(husband);
    $("#eventdate").val(date);
    $("#wife").val(wife);
    $("#phone").val(phone);

}

$(document).ready( function () {
    $('#eventTable').DataTable({
        "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Hebrew.json"
            }
    });
} );

function sendSMS(){


    $.ajax({
method:"POST",
url: "sms.php",
success:(data)=>{
    console.log(data);

        }
    })

}
</script>