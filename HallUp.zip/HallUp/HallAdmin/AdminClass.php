<?php
class Admin {

   public  $hallId;
    public $hallName;
 
    function __construct($hallId, $hallName)
    {
        $this->$hallId = $hallId;
        $this->$hallName = $hallName;
    }
 
 
 
 } // end of class Vegetable
?>