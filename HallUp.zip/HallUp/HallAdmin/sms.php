<?php
	// Account details
	$apiKey = urlencode('ZzQR2JPGxPM-ZhgqOVxPjFL1RebEddVfR0fSnj3KN4');
	
	// Message details
	$numbers = array(972546660540);
	$sender = urlencode('Zones');
	$message = rawurlencode('Please perform stock taking today ASAP. Our system having issues. Thanks, Kitty');
 
	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// Send the POST request with cURL
	$ch = curl_init('https://api.txtlocal.com/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	
	// Process your response here
	echo $response;
?>