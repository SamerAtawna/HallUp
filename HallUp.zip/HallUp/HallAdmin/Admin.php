<?php
 session_start();
require "../Connection/connection.php";
require "../cdn.html";
require 'AdminClass.php';
$user = [];
$username="";
$password="";
$halls=[];

if(isset($_POST["uname"])){
$username= $_POST["uname"];
$password= $_POST["pwd"];
} else{
    header('Location: /hallup/LoginPage/index.html');
}
$sql = "SELECT * FROM halls where username='".$username."' and password='".$password."'";
$result = mysqli_query($con,$sql);
$rowcount=mysqli_num_rows($result);
if($rowcount)
{
  $i = 0;
  while($row = mysqli_fetch_assoc($result))
  {
    $halls['HallId']    = $row['HallID'];
    $halls['Name'] = $row['Name'];
    $i++;
  }
  echo $halls['HallId'];
  $_SESSION["HallId"]= $halls['HallId'];
  $_SESSION["HallName"]= $halls['Name'];

  echo   $_SESSION["HallName"];
  header('Location: /hallup/HallAdmin/Events.php');

}
else 
{
 echo "<b>פרטים לא נכונים";
}
?>
