<?php

require "../Connection/connection.php";



$sql = "SELECT TableName, sum(NumberOfArrivals) as cnt, tables.Chairs from guest join tables on guest.TableName=tables.Name where tables.EventID={$_POST["eventid"]} group by TableName";
  
    if($result = mysqli_query($con,$sql))
    {
        while($row = mysqli_fetch_assoc($result)){
        // {{$row["Chairs"]} כסאות
            echo "<div class='tblCountName z-depth-1 blue-gradient '><div class='cntTitle'><span>שולחן </span>{$row["TableName"]}</div>";
            echo "<div class='cntChairs'><span>כסאות </span>{$row["Chairs"]}</div>";
            if($row["cnt"]>$row["Chairs"]){
                echo "<div class='cntChairs'><span  class=\"badge badge-danger\">תפוסה </span>{$row["cnt"]}</div>";
            }else{
                echo "<div class='cntChairs'><span>תפוסה </span>{$row["cnt"]}</div>";
            }
        
            echo "</div>";

  
    }

  }