<?php
require "../Connection/connection.php";


// Get the posted data.


if(isset($_POST["mealId"]) )
{



  // Update.
  $sql = "delete from meals where MealID = ".$_POST["mealId"];

  if(mysqli_query($con, $sql))
  {
    http_response_code(204);
  }
  else
  {
    echo"console.log(". mysqli_error($con).")";
  }  
}