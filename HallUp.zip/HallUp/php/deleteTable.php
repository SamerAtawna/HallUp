<?php
require "../Connection/connection.php";


// Get the posted data.


if(isset($_POST["tableid"]) )
{



  // Update.
  $sql = "delete from Tables where TableID = ".$_POST["tableid"];

mysqli_query($con, $sql);

$sql = "SELECT  * FROM Tables where EventID={$_POST["eventid"]}";

if($result = mysqli_query($con,$sql))
{


while($row = mysqli_fetch_assoc($result))
{
    echo "<div class=\"table night-fade-gradient\">";
    echo "<input type='hidden' id='tableid' value='{$row["TableID"]}'>";
    echo "  <div class=\"table-name\">{$row["Name"]}</div>";
    echo "<div class=\"table-chairs\">{$row["Chairs"]}</div>";
    echo "<div class=\"table-buttons\">";
    echo "<div class=\"btn-group\" role=\"group\" aria-label=\"Basic example\">";
    echo " <button type=\"button\" class=\"btn btn-primary btn-sm\">שינוי</button>";
    echo " <button type=\"button\" class=\"btn btn-danger btn-sm\" onclick='deleteTable({$row["TableID"]})'>מחיקה</button>";
    echo "</div></div></div>";
}
}
}
