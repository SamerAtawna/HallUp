<?php
require "../Connection/connection.php";


// Get the posted data.
echo "PHP";

if(isset($_POST["guestId"]) )
{



  // Update.
  $sql = "delete from guest where id = ".$_POST["guestId"];

  if(mysqli_query($con, $sql))
  {
    http_response_code(204);
  }
  else
  {
    echo  mysqli_error($con);
  }  
}