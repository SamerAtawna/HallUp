<?php
require "../Connection/connection.php";

$counters=[];
if(isset($_POST["selectedEventId"])){


$sql = "select count(`IsApproved`) as count FROM guest where `IsApproved`=0 and EventID={$_POST["selectedEventId"]}";
$result = mysqli_query($con,$sql);


  while($row = mysqli_fetch_assoc($result))
  {
    $counters['IsNotApproved']    = $row['count'];
  }

  $sql = "select count(`IsApproved`) as count FROM guest where `IsApproved`='1' and EventID='{$_POST["selectedEventId"]}'";
  $result = mysqli_query($con,$sql);
  
  
    while($row = mysqli_fetch_assoc($result))
    {
      $counters['IsApproved']= $row['count'];
    }
  
    $sql = "select sum(`NumberOfArrivals`) as count FROM guest where EventID='{$_POST["selectedEventId"]}'";
    $result = mysqli_query($con,$sql);
    
    
      while($row = mysqli_fetch_assoc($result))
      {
        $counters['Total']    = $row['count'];
      }

    $sql = "select count(`IsApproved`) as count FROM guest where `IsApproved`='2' and EventID='{$_POST["selectedEventId"]}'";
    $result = mysqli_query($con,$sql);
    
    
      while($row = mysqli_fetch_assoc($result))
      {
        $counters['Maybe'] = $row['count'];
      }
    }

      echo  json_encode($counters);

    $con->close();
    ?>