var number="";
var numofPayments;
var guest= {
    arrivals:0,
    id:0,
    eventId1:0,
    arrivalList:{}
}


setTimeout(() => {
    guest.eventId1 = eventId;
}, 1000);

var keypad={
 addNum(a){
    number+=a;
    $("#phoneNum").val(number);
    getUserInfo(  $("#phoneNum").val());
},
delNum(){
    number=number.slice(0,-1)
    $("#phoneNum").val(number);
},
clearKeypad(){
    number="";
    $("#phoneNum").val(number);
}};

var keyboard={
        row1:['ק','ר','א','ט','ו','ן','ם','פ'],
        row2:['ש','ד','ג','כ','ע','י','ח','ל','ך','ף'],
        row3:['ז','ס','ב','ה','נ','מ','צ','ת','ץ'],
        pressed:function (keyPress, cls){
            if(!(keyPress=='backspace')){
                    $('.'+cls).css("animation-play-state","running");
                    document.getElementById("name").value+=keyPress;

                    setTimeout(function(){
                        $('.'+cls).css("animation","none");
                    },500)

                    $('.'+cls).css("animation","animateKey 0.3s");
                } 
                else {
                    output=document.getElementById('name').value;
                    newName=output.substring(output.length-1,0 );
                    document.getElementById('name').value=newName;
                }
                getUserByName(document.getElementById("name").value);
        }
   
}
keyOut="";
c=1;
classId=0;
var wwww;
for(r in keyboard){
    console.log();
    if(r!='pressed'){
    keyOut+=`<div class=k${c}>`;
    for(i=0;i<keyboard[r].length;i++){
        keyOut+=`<div class=keyP${classId} onclick=keyboard.pressed('${keyboard[r][i]}','keyP${classId}')>${keyboard[r][i]}</div>`;
        if(i==7 && keyboard[r].length==8){
            keyOut+="<div class='backspace' onclick=keyboard.pressed('backspace')><</div>";
        }
    classId++;
    }
    keyOut+="</div>";
    c++;
    document.getElementById("keyb").innerHTML=keyOut;

}

};

function getUserInfo(phoneNumber){
    $.ajax({
        
        method:"POST",
        url: "../php/api.php?q=phoneNumber",
        data:{
            "phoneNumber" :phoneNumber
        
        },
        success:(data)=>{
            let newd = JSON.parse(data);
            console.log(newd);
            if(newd.length!=0){
            $(".userDetails").html(` ערב טוב  ${newd[0].fullname} 
            ,<br><br>
            מספר המוזמנים הוא 
            ${newd[0].numOfArrivals}.<br>במסך הבא ניתן לבחור את המנות . בתאבון!
            <div class="mealBtn2">
            <a href="#" onclick="gotoMenu()" class="BUTTON_HCW">בחירת מנה</a>
         </div>  `);
         guest.arrivals = newd[0].numOfArrivals;
         guest.id = newd[0].guestId;
            $(".userDetails").css('width','60%');
            $(".userDetails").css('font-size','60px');
            }
           
        }

    })
}
function getUserByName(guestName){ //Search user by info 
    console.log("in func");
    if(!(guestName=="")){
    $.ajax({
        
        method:"POST",
        url: "../php/api.php?q=byname",
        data:{
            "guestName" :guestName,
            "eventid": eventId
        
        },
        success:(data)=>{
            console.log(data);
            $("#byNameResult").html(data);
        }
    })
}else{
    $("#byNameResult").html("");
}
}

function getMenu(){
    for(let i=1; i<=guest.arrivals; i++){
        guest.arrivalList[i] = {meals:[0,0]};

    }
  
    $.ajax({
        
        method:"POST",
        url: "../php/api.php?q=menu",
        data:{
            "guestId" :guest.id,
            "arrivals": guest.arrivals,
            "eventId": guest.eventId1,
        
        },
        success:(data)=>{
          $(".Menu").html(data);
           
        }

    })
}

function makeOrder(){
    let guest1 = JSON.stringify(guest);

    $.ajax({
        
        method:"POST",
        url: "../php/api.php?q=order",
        data:{
            "guest" :guest1
        
        },
        success:(data)=>{
       console.log(data);
           
        }

    })

}
function setGuestInfo(eventId, numOfArrivals, guestId){
guest.arrivals = numOfArrivals;
guest.id = guestId;
guest.eventId1 = eventId;
for(let i=1; i<=guest.arrivals; i++){
    guest.arrivalList[i] = {meals:[0,0]};

}
$.ajax({
    method:"POST",
    url: "../php/api.php?q=menu",
    data:{
        "guestId" :guest.id,
        "arrivals": guest.arrivals,
        "eventId": guest.eventId1,
    
    },
    success:(data)=>{
      $(".Menu").html(data);
     // gotoMenu();
      gotoFirstMenu();
    }
})

}
function setPayment(payment, e){
this.numofPayments = payment;
$(e).siblings().css("border","none");
$(e).css({"border":"5px solid white", "border-radius":"5px"});


}