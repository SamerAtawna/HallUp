<html dir="rtl">
<?php
require "../Connection/connection.php";
require "../cdn.html";

?>
<nav class="navbar navbar-dark bg-dark blue-gradient">
    <div class="main">
<a class="navbar-brand" href="/Hallup/UserDashboard/index.php">ניהול אורחים</a>
<a class="navbar-brand" href="/Hallup/UserDashboard/Meals.php">בחירת מנות</a>
</div>
</nav>
