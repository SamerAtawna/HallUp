
<?php
require "../Connection/connection.php";
require "../cdn.html";
?>
<nav class="navbar navbar-dark bg-dark">
    <div class="main">
<a class="navbar-brand" href="Events.php">אירועים</a>

</div>
</nav>
