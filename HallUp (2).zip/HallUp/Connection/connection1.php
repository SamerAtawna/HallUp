
<?php

$serverName = "lcsmkcafe02, 3180"; //serverName\instanceName, portNumber (default is 1433)
$connectionInfo = array( "Database"=>"CDIS", "UID"=>"ad_salataox", "PWD"=>"1@password", "CharacterSet" => "UTF-8");
$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( $conn ) {
  //   echo "Connection established.<br />";
}else{
     echo "Connection could not be established.<br />";
     die( print_r( sqlsrv_errors(), true));
}
?>