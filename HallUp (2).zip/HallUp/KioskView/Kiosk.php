
<?php
require "../Connection/connection.php";
require "../cdn.html";
if(isset($_POST["userName"]) && isset($_POST["password"]) && isset($_POST["eventID"])){
   $eventId="";
   $husband="";
   $wife="";
   $sql = "SELECT * FROM `halls` join events on halls.HallID = events.HallID where eventID={$_POST["eventID"]} and halls.UserName = '{$_POST["userName"]}' and halls.Password = '{$_POST["password"]}'";
   $result = $con->query($sql);

   if($result->num_rows > 0)
   {


      while($row = $result->fetch_assoc())
      {        
         $eventId=$row["EventID"];
         $husband=$row["Husband"];
         $wife=$row["Wife"];
        
      }
   } 
   
}



?>
<html xmlns="http://www.w3.org/1999/xhtml"  lang="he" dir="rtl">
   <head>
      <title>hallUp</title>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <script
         src="https://code.jquery.com/jquery-3.3.1.js"
         integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
         crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="./Style/Animations.css">
      <link rel="stylesheet" type="text/css" href="./Style/Imports.css">
      <link rel="stylesheet" type="text/css" href="./Style/keypad.css">
      <link rel="stylesheet" type="text/css" href="./Style/style.css">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.6/css/mdb.min.css" rel="stylesheet">
      <style>
      #byNameResult{
         color:white;
         display: flex;
         justify-content: center;
         text-align:right;
         transition: all 2s;
}

#byNameResult > ul {
   width:400px;
   list-style: none;
   font-size:30px;
   transition: all 2s;
}
#guestList li{
   border: 1px solid;
    border-radius: 8px;
    margin: 5px;
    padding: 10px;
    color:#25262e;
    transition:all 1s;

}
#guestList li:first-child{
    border:none;
    color:white
   }

   .meal img{
      width:100%;
   }
      </style>
   </head>
   <body>
      <form id="AdminForm">
         <div class="main">
            <div class="modal">
               <div class="coupleNames"> <!--First View Begin -->
             <?php echo $husband." & ".$wife; ?>  
               </div>
                   <!--First View End -->
               <div class="identify"> <!--Second View Begin -->
             
                  <div class="keypad">
                     <h2>  מספר פלאפון</h2>
                     <div class="containerKeypad">
                        <div class="output">
                            <input type="text" id="phoneNum">
                        </div>
                        <div class="row1">
                           <input type=button value=1 onclick="keypad.addNum(this.value)" />
                           <input type=button value=2 onclick="keypad.addNum(this.value)" />
                           <input type=button value=3 onclick="keypad.addNum(this.value)" />
                        </div>
                        <div class="row2">
                           <input type=button value=4 onclick="keypad.addNum(this.value)" />
                           <input type=button value=5 onclick="keypad.addNum(this.value)" />
                           <input type=button value=6 onclick="keypad.addNum(this.value)" />
                        </div>
                        <div class="row3">
                           <input type=button value=7 onclick="keypad.addNum(this.value)" />
                           <input type=button value=8 onclick="keypad.addNum(this.value)" />
                           <input type=button value=9 onclick="keypad.addNum(this.value)" />
                        </div>
                        <div class="row4">
                           <input type=button value="איפוס" onclick="keypad.clearKeypad()" />
                           <input type=button value=0 onclick="keypad.addNum(this.value)" />
                           <input type=button value="מחיקה" onclick="keypad.delNum()" />
                        </div>
                     </div>
                  </div>
                  <div class="userDetails">
                  
                  </div>
               
               </div>
            
               <div class="devider">
               או
               </div>
               <div class="byName">
                     <h2>הקלד שם</h2>
                     <div class="nameEnter">
                         <input type="text" ID="name">
                      
                     </div>
                  </div>
               <div id="keyb"></div>
               <div id="byNameResult">
                  
                  </div>
               <!-- <div class="mealBtn2">
                  <a href="#" onclick="gotoMenu()" class="BUTTON_HCW">בחירת מנה</a>
               </div>   -->
               <div class="Menu">
          <!--Second View End -->
    
         </div>

     
         <script src="Functions.js"></script>
         <script src="Transitions.js"></script>
      </form>

<script>
var eventId=<?php echo $eventId?>;
var firstMeal;
var lastMeal;
var user = $("#phoneNum").val();
function mealChoosen(mealId, name, categoryId, guestSeq){
switch (categoryId) {
   case 1:$("#guest-first-"+guestSeq).html(name); $(".FirstMeal").css("animation-play-state","running"); guest.arrivalList[guestSeq].meals[0] = mealId ;  break
   case 2:$("#guest-last-"+guestSeq).html(name);$(".LastMeal").css("animation-play-state","running"); guest.arrivalList[guestSeq].meals[1] = mealId ; break
   }
}
   </script>

   </body>
</html>