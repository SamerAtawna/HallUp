<?php 
require "../cdn.html";

?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
  <link rel="stylesheet" type="text/css" href="./Style/style.css">  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kiosk Login</title>
</head>
<body>
    <div class="container login">
                        <form class="text-center p-5" action="Kiosk.php" method="post">

                    <p class="h4 mb-4">מסך כניסה</p>

                    <!-- Name -->
                    <input type="text" name="userName" class="form-control mb-4" placeholder="שם משתמש">

                    <!-- Email -->
                    <input type="password" name="password" class="form-control mb-4" placeholder="סיסמא">

                    <!-- Subject -->
                    <input type="text" name="eventID" class="form-control mb-4" placeholder="מזהה אירוע">
                 
                    <!-- Message -->
                
                    <!-- Copy -->
           

                    <!-- Send button -->
                    <button class="btn btn-info btn-block" type="submit">כניסה</button>

                    </form>
                    <!-- Default form contact -->
    </div>
</body>
</html>