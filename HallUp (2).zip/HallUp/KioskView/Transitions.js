//Navigating between different Views



function gotoMeals(){
$(".main").css("animation-play-state","running");
$(".coupleNames").slideUp();
$(".mealBtn").slideUp();
$(".keypad").css("display","flex");
$(".identify").css("display","flex");
$(".containerKeypad").slideDown();
$("#keyb").slideDown();
$(".mealBtn2").css("display","flex");
$(".ByName").css("display","flex");
}

function gotoMenu(){
    getMenu();
    $(".main").css("animation-play-state","running");
    $(".keypad").slideUp();
    $(".ByName").slideUp();
    $(".Keyb").slideUp();
    $(".k1, .k2, .k3 ").slideUp();
    $(".Menu").css("display","flex");
    $(".mealBtn2").slideUp();
    $("#keyb").slideUp();
    $(".devider").slideUp();
    $(".userDetails").slideUp();
    $("#byNameResult").slideUp();
}