<?php
/**
 * Returns the list of policies.
 */
require 'connection.php';
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
$user = [];


$username =$_GET["username"];
$password = $_GET["password"];
$sql = "SELECT * FROM halls where username='".$username."' and password='".$password."'";
$result = mysqli_query($con,$sql);
$rowcount=mysqli_num_rows($result);
if($rowcount)
{
  $i = 0;
  while($row = mysqli_fetch_assoc($result))
  {
    $halls[$i]['HallId']    = $row['HallID'];
    $halls[$i]['Name'] = $row['Name'];
    $i++;
  }

  print_r(json_encode($halls));
}
else 
{
  http_response_code(404);
}