<?php
require "../Connection/connection.php";


// Get the posted data.


if(isset($_POST["evid"]) )
{



  // Update.
  $sql = "delete from events where EventID = ".$_POST["evid"];

  if(mysqli_query($con, $sql))
  {
    http_response_code(204);
  }
  else
  {
    return http_response_code(422);
  }  
}