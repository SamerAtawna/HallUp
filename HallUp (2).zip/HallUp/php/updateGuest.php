<?php
require "../Connection/connection.php";


// Get the posted data.


if(isset($_POST["guestid"]) )
{



  // Update.
echo $_POST["guestid"];
  $sql = "update guest set FullName='".$_POST["name"]."', Phone='".$_POST["phone"]."', NumberOfArrivals='".$_POST["arrive"]."' where id=".$_POST["guestid"];

  if(mysqli_query($con, $sql))
  {
    http_response_code(204);
  }
  else
  {
    return http_response_code(422);
  }  
}