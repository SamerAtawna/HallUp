<?php
require "../Connection/connection1.php";

$id = $_GET["q"];



if($id=="insert"){
  $date=$_GET["date"];
  $serial=$_GET["serial"];
  $user=$_GET["user"];
  $issue=$_GET["issue"];
  $hours=$_GET["hours"];
  $date1 = new DateTime($date); 

    $sql = "INSERT INTO hours (Date, Employee, Charge, Hostname, Issue) VALUES ('{$date}','{$user}','{$hours}','{$serial}','{$issue}')";
    $result = sqlsrv_query($conn,$sql);
    if($result)
    {
      echo "success";

      header("HTTP/1.1 200 OK");

   
    }
    else
    {
        echo "error";
        
        die( print_r( sqlsrv_errors(), true));
        header("Status: 404 Not Found");

    }

}

if($id=="reports"){
 
  $hours = [];
  $obj = array();
  $from = $_GET["from"];
  $to = $_GET["to"];
  $sql = "SELECT * FROM  hours where DATE between '{$from}' and '{$to}'";


  $stmt = sqlsrv_query( $conn, $sql);
  while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {

         $obj =array ("Date" => $row["Date"],"User"=>$row["Employee"],"Charge"=>$row["Charge"],"Hostname"=>$row["Hostname"],"Issue"=>$row["Issue"]);
         array_push($hours, $obj);
      }
      echo json_encode($hours);
  }

  if($id=="WWID"){
    $name = [];
$wwid1 = $_GET["WWID"];
$u = array();
  $sql = "SELECT TOP 1 * FROM  WorkerPublicExtended where WWID='${wwid1}'";
  $stmt = sqlsrv_query( $conn, $sql);
  while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {

    $u = array("FirstName"=> $row["FirstName"],"LastName"=> $row["LastName"]);
   
 }
 echo json_encode($u);



  }

  if($id=="models"){
    $models = array();
$sql = "select * from Sheet1$";
  $stmt = sqlsrv_query( $conn, $sql);
while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
array_push($models, $row["F1"]);
}

echo json_encode($models);
  }

  if($id=="techs"){

    $models = array();
  $sql = "select * from techs";
  $stmt = sqlsrv_query( $conn, $sql);
while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
array_push($models, $row["Technician"]);
}

echo json_encode($models);

  }

  if($id=="insertlabel"){
    echo "from func";
    $wwid=$_GET["wwid"];
    $save=$_GET["save"];
    $tech=$_GET["tech"];
    $model=$_GET["model"];
    $name=$_GET["name"];
    $serial=$_GET["serial"];
    $machine=$_GET["machine"];
    $type=$_GET["type"];
    $date1 = date("Y-m-d H:i:s");
  
      $sql = "INSERT INTO Labels (WWID, SaveTill, Technician, Model, FullName, Serial, Machine, Type) VALUES ('{$wwid}','{$save}','{$tech}','{$model}','{$name}','{$serial}','{$machine}','{$type}')";
      $result = sqlsrv_query($conn,$sql);
      if($result)
      {
        echo "success";
  
        header("HTTP/1.1 200 OK");
  
     
      }
      else
      {
          echo "error";
          
          die( print_r( sqlsrv_errors(), true));
          header("Status: 404 Not Found");
  
      }
  
  }

  

  if($id=="getLabelsList"){
 
    $hours = [];
    $obj = array();
    $sql = "SELECT * FROM  Labels";
  
  
    $stmt = sqlsrv_query( $conn, $sql);
    while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
  
           $obj =array ("Id"=>$row["id"],"WWID" => $row["WWID"],"SaveTill"=>$row["SaveTill"],"Technician"=>$row["Technician"],"Model"=>$row["Model"],"FullName"=>$row["FullName"],"Serial"=>$row["Serial"],"Machine"=>$row["Machine"],"Type"=>$row["Type"]);
           array_push($hours, $obj);
        }
        echo json_encode($hours);
    }

    if($id=="deletelabel"){

    $idd = $_GET["lblid"];
      $sql = "delete from Labels where id=".$idd."";
       $result = sqlsrv_query($conn,$sql);
        if($result)
        {
          echo "success";
    
          header("HTTP/1.1 200 OK");
    
       
        }
        else
        {
            echo "error";
            
            die( print_r( sqlsrv_errors(), true));
            header("Status: 404 Not Found");
    
        }
    
    }
?>
