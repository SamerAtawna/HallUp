<?php
require "../Connection/connection.php";


// Get the posted data.
$tblid;
$gid;

if(isset($_POST["tablename"]) )
{

    $sql = "update guest set TableName='{$_POST["tablename"]}' where id ='{$_POST["guestid"]}'";
    echo $sql;
    if(mysqli_query($con, $sql))
    {
      http_response_code(200);
    }

}
echo mysqli_error($con);
