USE [boIntel]
GO
/****** Object:  StoredProcedure [dbo].[PayrollReport]    Script Date: 07/02/2019 14:11:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kehat, Megidish
-- Create date: 14/04/2013
-- Description:	Payroll Report.
-- =============================================
ALTER PROCEDURE [dbo].[PayrollReport] ----11625552,'2016/06/01','2016/06/13'
                    @userWWID int ,
                    @StartDate nvarchar(50),
                    @EndDate nvarchar(50)
AS
BEGIN
set dateformat dmy
SET DATEFIRST 7
SET concat_null_yields_null OFF

Declare @StartDate1 datetime, 
@EndDate1 datetime, 
@DateSwitch varchar(5), 
@StartDate2 varchar(20), 
@EndDate2 varchar(20),
@MinEmpID int,
@MaxEmpID int,
@MinCompanyCode int,
@MaxCompanyCode int,
@MinCostCenter int,
@MaxCostCenter int

Set @StartDate1 = @StartDate
Set @EndDate1 = @EndDate
Set @DateSwitch = '21:00'
Set @StartDate2 = @StartDate + ' 21:00:00'
Set @EndDate2 = @EndDate + ' 20:59:59'
begin
if (@userWWID = 0)
   begin
      set @MinEmpID = 2
      set @MaxEmpID = 99999999
   end
else
   begin
      Set @MinEmpID = @userWWID
      Set @MaxEmpID = @userWWID
   end
end
     
Set @MinCompanyCode = 0
Set @MaxCompanyCode = 999999
Set @MinCostCenter = 0
Set @MaxCostCenter = 999999;

------ Get MaxDates of all employees and distinct WWID by last shown campus. Kehat, Megidish 22/04/2013 ------
select e.Emp_ID AS EmpID,e.[Date] AS maxDate,e.Campus
into #maxDates
from Employees as e
where (CONVERT(datetime,e.[Date]) BETWEEN @StartDate1 AND @EndDate1) 
and CONVERT(datetime,e.[Date]) =(select max(CONVERT(datetime,e1.[date])) 
                                 from Employees e1 
                                 where e1.Emp_ID = e.Emp_ID
                                 and CONVERT(datetime,e1.[Date]) BETWEEN @StartDate1 AND @EndDate1)

--select * from #maxDates

SELECT     
	case 
	   when convert(varchar, [לשעה],8) >= @DateSwitch then dateadd(d,1,[הזמנות].[ת-הזמנה]) 
	   else [הזמנות].[ת-הזמנה] 
	end as ForDate,
	Emp_ID AS [מספר עובד],
	Fname + ' ' + Lname as [שם עובד],
	[שם המזמין] AS סמל, 
	Campus.Name as [קמפוס],
	([סהכ]/100) as AmtByDay,
	([סהכ]/100)*Cost_Full_Meal as [NISPrice]
INTO #tbl
FROM Employees INNER JOIN #maxDates 
ON Employees.Emp_ID = #maxDates.EmpID AND Employees.Date = #maxDates.maxDate 
        INNER JOIN הזמנות 
ON Employees.Emp_ID = הזמנות.[מס לקוח] 
        INNER JOIN Registers 
ON הזמנות.[קוד קופה] = Registers.ID 
        INNER JOIN Cafeteria 
ON Registers.Cafeteria = Cafeteria.ID --AND #maxDates.Campus = Cafeteria.Campus 
        INNER JOIN Campus 
ON #maxDates.Campus = Campus.ID
Where ([Cost_Center] Between @MinCostCenter and @MaxCostCenter ) 
AND ([Company_Code] Between @MinCompanyCode and @MaxCompanyCode )  
AND  relo_status in (1,2) 
AND emp_id <> 1 
AND Emp_ID between @MinEmpID and @MaxEmpID
AND ([לשעה] Between @StartDate2 and @EndDate2 ) 
--Edited By Hadar AND campus.id <> 4

--select * from #tbl

select ForDate,[שם עובד],[מספר עובד],סמל, [קמפוס], sum(AmtByDay) as AmountDay,sum([NISPrice]) as TotPrice,
       case  when (SUM(AmtByDay))> (case (select top 1 [מען לדואר] 
										  from [לקוחות] 
										  where [מס לקוח] = [מספר עובד]) 
  									when 1 then 1.25 
									when 2 then 1.56 
		 							else 5000 end) 
		 	  AND סמל in ('159','2141')  
			  then  SUM(AmtByDay) - (case (select top 1 [מען לדואר] 
												         from [לקוחות] 
												         where [מס לקוח] = [מספר עובד]) 
										           when 1 then 1.25 
										           when 2 then 1.56 
										           else 5000 end)
             --when סמל = '604' 
             --     then SUM(AmtByDay)
	  else 0 end as DeviationByDay,
      case (select top 1 [מען לדואר] 
	        from [לקוחות] 
	        where [מס לקוח] = [מספר עובד]) 
  							 when 1 then 'מנהלה' 
							 when 2 then 'משמרות'
							 else 'כללי' end as EmpType
INTO #t2
from #tbl
group by [מספר עובד],[שם עובד], סמל, [קמפוס],ForDate

--select * from #t2

select [שם עובד],[מספר עובד],608 as [סמל] , [קמפוס],0 as [סהכ צריכה בתקופה],0 as [עלות צריכה בשח],
       sum(DeviationByDay) as [סהכ סטייה יומית],
       (sum(TotPrice) /sum(AmountDay))*sum(DeviationByDay) as [ערך הסטייה לתקופה],EmpType
INTO #t3
from  #t2
group by [מספר עובד],[שם עובד], [קמפוס],EmpType

--select * from #t3


SELECT
	#t2.[שם עובד],
	#t2.[מספר עובד],
	#t2.[סמל], 
	#t2.[קמפוס],
	case when #t2.[סמל] = 159  then sum(#t2.AmountDay) - ISNULL(#t3.[סהכ סטייה יומית],0) else sum(#t2.AmountDay) end as [סהכ צריכה בתקופה],
	case when #t2.[סמל] = 159  then sum(#t2.TotPrice) - ISNULL(#t3.[ערך הסטייה לתקופה],0) else sum(#t2.TotPrice) end as [עלות צריכה בשח],
	'0' as [סהכ סטייה יומית],
	'0' as [ערך הסטייה לתקופה],
	#t2.EmpType
FROM  #t2 join #t3 ON #t2.[מספר עובד] = #t3.[מספר עובד]
group by #t2.[מספר עובד],#t2.[שם עובד], #t2.[סמל], #t2.[קמפוס],#t3.[סהכ סטייה יומית],#t3.[ערך הסטייה לתקופה],#t2.EmpType

union

SELECT 
    [שם עובד],
	[מספר עובד],
	[סמל],
	[קמפוס],
	[סהכ צריכה בתקופה],
	[עלות צריכה בשח],
	[סהכ סטייה יומית],
	[ערך הסטייה לתקופה],
	EmpType
FROM  #t3
WHERE cast([סהכ סטייה יומית] as money) > 0
order by [מספר עובד]

drop table #maxDates
drop table #tbl
drop table #t2
drop table #t3
END
