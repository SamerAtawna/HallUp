<?php 
session_start();
require "../cdn.html";
require "../AdminNav/Nav.php";

?>
<div class="alert alert-success" role="alert">
  הפעולה בוצעה בהצלחה
</div>

<div class="container">
<?php
if(isset($_POST["eventid"])){
    echo "<h3> התפריט של ".$_POST["husband"]." ו".$_POST["wife"]."</h3>";
    echo "<input type='hidden' id='eventidselected' value='".$_POST["eventid"]."'>";
}
?>
<button type="button" id="addm" class='btn btn-success' style="width:20%"  data-toggle='modal' data-target='#mealModal'>הוסף מנה  &nbsp  <i class="far fa-plus-square"></i></button>
<div class="firstMeal">
    <div class="fMealTitle"> מנה ראשונה</div>
            <div class="fMealMenu">
            <?php

            $sql = "SELECT * FROM meals where CatID=1 and EventId=".$_POST["eventid"];

            if($result = mysqli_query($con,$sql))
            {
                while($row = mysqli_fetch_assoc($result))
                {
                    echo "<div class=\"meal\">";
                    echo $row["Name"];
                    echo "<img id='mealimage' src='../php/upload/{$row["Pic"]}'>";
                    echo "<div class='mealButtons'> <button type=\"button\" onclick='delMeal(".$row["MealID"].")' class='btn btn-danger btn-sm'><i class=\"fas fa-trash\"></i></button>";
                    echo "<button type=\"button\" class='btn btn-primary btn-sm'  data-toggle='modal' data-target='#picModal' onclick=\"setMealId({$row["MealID"]})\"><input type=\"hidden\" id=\"mealId\">עדכן תמונה</button></div>";
                    echo "</div>";
            }
        } else{
            echo mysqli_error($con);
        }
            ?>
          </div>  
              </div>

 
<div class="lastMeal">
<div class="lMealTitle"> מנה עיקרית</div>
            <div class="lMealMenu">
            <?php

$sql = "SELECT * FROM meals where CatID=2 and EventId=".$_POST["eventid"];

if($result = mysqli_query($con,$sql))
{
    while($row = mysqli_fetch_assoc($result))
    {
        echo "<div class=\"meal\">";
        echo $row["Name"];
        echo "<img id='mealimage' src='../php/upload/{$row["Pic"]}'>";
        echo "<div class='mealButtons'> <button type=\"button\" onclick='delMeal(".$row["MealID"].")' class='btn btn-danger btn-sm'><i class=\"fas fa-trash\"></i></button>";
        echo "<button type=\"button\" class='btn btn-primary btn-sm'   data-toggle='modal' data-target='#picModal' onclick=\"setMealId({$row["MealID"]})\"><input type=\"hidden\" id=\"mealId\">עדכן תמונה</button></div>";
        echo "</div>";
  }
} else{
echo mysqli_error($con);
}
?>
            </div>
</div>

</div>
</div>
<!-- Create Meal -->
<div class="modal fade" id="mealModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">הוספת מנה</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <span>קטגוריה</span>      <select class="form-control" id="mealcat">
      <option value="1">מנה ראשונה</option>
      <option value="2">מנה עיקרית</option>
      
    </select>
      <span>שם</span>  <input type=text size="20"  class="form-control" id="mealname">
      <span>תמונה</span>  <input size="16" type="text"  class="form-control" id="mealpic" value="" class="form_datetime">
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ביטול</button>
        <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="addMeal()">שמירה</button>
      </div>
    </div>
  </div>
</div>

<!-- Update Image Modal -->
<div class="modal fade" id="picModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">הוספת מנה</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <span>תמונה</span>     
      <form method="post" action="" enctype="multipart/form-data" id="myform">
                <input type=file id="file" size="20"  class="form-control" required>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">ביטול</button>
  
        <button type="button" class="btn btn-primary" id="but_upload">שמירה</button>
</form>
      </div>
    </div>
  </div>
</div>

<script>
function setMealId(d){
$("#mealId").val(d);
}

$("#but_upload").click(function(){

var fd = new FormData();
var files = $('#file')[0].files[0];
fd.append('file',files);
var selectedMealId = $("#mealId").val();
fd.append('mealid',selectedMealId);
$.ajax({
    url: '../php/uploadImage.php',
    type: 'post',
    data: fd,
    contentType: false,
    processData: false,
    success: function(response){
        if(response != 0){
     console.log(response);

        }else{
          console.log(response);
        }
    },
});
window.location.reload();
});

function showSuccess(){
 $('.alert').slideDown();
 setTimeout(() => {
  $('.alert').slideUp();
 }, 3000);
}
</script>