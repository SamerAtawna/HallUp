//Navigating between different Views



function gotoMeals(){
$(".main").css("animation-play-state","running");
$(".coupleNames").slideUp();
$(".mealBtn").slideUp();
$(".keypad1").css("display","flex");
$(".identify").css("display","flex");
$(".containerKeypad").slideDown();
$("#keyb").slideDown();
$(".mealBtn2").css("display","flex");
$(".ByName").css("display","flex");
}

function gotoMenu(){
    getMenu();
    $(".main").css("animation-play-state","running");
    $(".keypad1").slideUp();
    $(".ByName").slideUp();
    $(".Keyb").slideUp();
    $(".k1, .k2, .k3 ").slideUp();
    $(".Menu").css("display","flex");
    $(".mealBtn2").slideUp();
    $("#keyb").slideUp();
    $(".devider").slideUp();
    $(".userDetails").slideUp();
    $("#byNameResult").slideUp();
    $(".firstMenu").slideUp();
    $(".modal1").css("justify-content","flex-start");
}
function gotoFirstMenu(){
    $(".main").css("animation-play-state","running");
    $(".keypad1").slideUp();
    $(".ByName").slideUp();
    $(".Keyb").slideUp();
    $(".k1, .k2, .k3 ").slideUp();
    $(".mealBtn2").slideUp();
    $("#keyb").slideUp();
    $(".devider").slideUp();
    $(".userDetails").slideUp();
    $("#byNameResult").slideUp();
    $(".firstMenu").slideDown();
    $(".firstMenu").css("display","flex");
    $(".modal-content").css("border-radius","20px");
    $(".modal-content").css("box-shadow","0px 1px 20px 0px");
    $(".modal-header").css("border","none");
    $(".modal-footer").css("border","none");
    $(".btn").css({"background-color":"gold !important","color":"black"});
    $(".modal-footer").css({"display":"flex","justify-content":"space-evenly"});



}