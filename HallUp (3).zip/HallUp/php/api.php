<?php
require "../Connection/connection.php";

$id = $_GET["q"];


if($id=="auth"){

    $username;
    $password;
    $user=Array();
    if(isset($_GET["username"])){
 
        $username= $_GET["username"];
        $password= $_GET["pwd"];
 
    }

    $sql = "SELECT * FROM events where Phone='".$username."' and password='".$password."'";
    $result = mysqli_query($con,$sql);
    $rowcount=mysqli_num_rows($result);
    if($rowcount)
    {
  
        while($row = mysqli_fetch_assoc($result))
        {
       $user = array("isOk"=> true, "eventid"=> $row['EventID'], "husband"=> $row['Husband'],"wife"=> $row['Wife'], "date"=> $row['Date']);
   
        }

        }
        else{
            $user = array("isOk"=>false);
        
        }
        echo json_encode($user);
    
    }


    if($id=="guests"){
        $eventid=$_GET["eventid"];
        $guest = [];
        $obj = array();
        
        $sql = "SELECT * FROM guest where EventID=".$eventid;
        $result = mysqli_query($con,$sql);
        $rowcount=mysqli_num_rows($result);
        if($rowcount)
        {
            while($row = mysqli_fetch_assoc($result))
            {
               $obj =array ("fullname" => $row["FullName"],"phone"=>$row["Phone"],"numberofarrivals"=>$row["NumberOfArrivals"],"isapproved"=>$row["IsApproved"]);
               array_push($guest, $obj);
            }
        }
        echo json_encode($guest);

    }

    if($id=="counters"){
        $eventid=$_GET["eventid"];
        $guest = [];
        $obj = array();

        $sql = "select IsApproved, count(*) as Number from guest where EventID=2 GROUP by IsApproved";
        $result = mysqli_query($con,$sql);
        $rowcount=mysqli_num_rows($result);
        if($rowcount)
        {
            while($row = mysqli_fetch_assoc($result))
            {
               $obj =array ("IsApproved" => $row["IsApproved"],"Number"=>$row["Number"]);
               array_push($guest, $obj);
            }
        }

        $sql = "select count(id) as guests from guest where EventID=2";
        $result = mysqli_query($con,$sql);
        $rowcount=mysqli_num_rows($result);
        if($rowcount)
        {
            while($row = mysqli_fetch_assoc($result))
            {
               $obj =array ("guestsCount" => $row["guests"]);
               array_push($guest, $obj);
            }
        }
        echo json_encode($guest);

    }

    if($id=="addguest"){
        $eventid=$_GET["eventid"];
        $guest = [];
        $obj = array();

        $sql = "INSERT INTO `guest`(`EventID`, `FullName`, `Phone`, `NumberOfArrivals`, `IsApproved`) VALUES ('{$eventid}','{$_GET["gName"]}','{$_GET["gPhone"]}','{$_GET["gPeople"]}','{$_GET["gArrive"]}')";

  if(mysqli_query($con,$sql))
  {
    echo "success";
    echo mysqli_error($con);
  
 
  }
  else
  {
    echo mysqli_error($con);
  
  }
    }

// Get user details 
if($id=="phoneNumber"){
    $phone=$_POST["phoneNumber"];
    $guest = array();
    $sql = "SELECT * FROM guest where Phone='".$phone."'";
    $result = mysqli_query($con,$sql);
    $rowcount=mysqli_num_rows($result);
    if($rowcount)
    {
        while($row = mysqli_fetch_assoc($result))
        {
           $obj =array ("fullname" => $row["FullName"], "numOfArrivals" => $row["NumberOfArrivals"], "guestId" => $row["id"]);
           array_push($guest, $obj);
        }
    }
    echo json_encode($guest);

}

//get menu per user
if($id=="menu"){
    $guestId=$_POST["guestId"];
    $arrivals=$_POST["arrivals"];
    $eventId=$_POST["eventId"];
    $guestSeq = 1;
    echo "<ul class=\"nav nav-tabs\" id=\"myTab\" role=\"tablist\">";
    for($i=1; $i<=$arrivals;$i++){//Tabs
        if($i==1){
            echo "<li class=\"nav-item\">";
            echo "<a class=\"nav-link active\" id=\"home-tab\" data-toggle=\"tab\" href=\"#guest".$guestSeq."\" role=\"tab\" aria-controls=\"home\" aria-selected=\"true\">אורח ".$guestSeq." </a>";
            echo "  </li>";
            $guestSeq++;
        }else{
        echo "<li class=\"nav-item\">";
        echo "<a class=\"nav-link\" id=\"home-tab\" data-toggle=\"tab\" href=\"#guest".$guestSeq."\" role=\"tab\" aria-controls=\"home\" aria-selected=\"true\">אורח ".$guestSeq." </a>";
        echo "  </li>";
        $guestSeq++;
        }
    }
    $guestSeq = 1;
    echo "</ul>";
    echo "<div class=\"tab-content\" id=\"myTabContent\">";//Tab content
    for($i=1; $i<=$arrivals;$i++){
    if($i==1){
        echo " <div class=\"tab-pane fade  show active\" id=\"guest".$guestSeq."\" role=\"tabpanel\" aria-labelledby=\"guest".$guestSeq."-tab\">";
    }else{
        echo " <div class=\"tab-pane fade\" id=\"guest".$guestSeq."\" role=\"tabpanel\" aria-labelledby=\"guest".$guestSeq."-tab\">";
    }

    //Menu 
    echo "<div class=\"MenuOption\">";
    echo"<div class=\"title z-depth-1-half\">מנה ראשונה</div>";
    echo "<div class=\"MenuItems\">";
    $sql = "SELECT * FROM `eventmeals` join meals on eventmeals.MealID = meals.MealID where eventmeals.EventID={$eventId} and eventmeals.CatID=1";

    if($result = mysqli_query($con,$sql))
    {
       while($row = mysqli_fetch_assoc($result))
       {
          echo "<div class='meal peach-gradient' onclick=\"mealChoosen({$row["MealID"]}, '{$row["Name"]}', {$row["CatID"]},${guestSeq})\"><img src='../php/upload/{$row["Pic"]}''>{$row["Name"]}</div>";
       }
    }
echo "</div>";
echo "</div>";
echo "<div class=\"MenuOption\">";
echo"<div class=\"title z-depth-1-half\">מנה עיקרית</div>";
echo "<div class=\"MenuItems\">";
$sql = "SELECT * FROM `eventmeals` join meals on eventmeals.MealID = meals.MealID where eventmeals.EventID={$eventId} and eventmeals.CatID=2";

if($result = mysqli_query($con,$sql))
{
   while($row = mysqli_fetch_assoc($result))
   {
      echo "<div class='meal peach-gradient' onclick=\"mealChoosen({$row["MealID"]}, '{$row["Name"]}', {$row["CatID"]},${guestSeq})\"><img src='../php/upload/{$row["Pic"]}''>{$row["Name"]}</div>";
   }
}
echo "</div>";
echo "</div>";

echo "<div class=\"MenuOption\">";
echo"<div class=\"title z-depth-1-half\">הבחירה שלכם</div>";
echo "<div class=\"MenuItems\">";
echo "<div class=\"FirstMeal\">";
echo "<div class=\"title\">";
echo " מנה ראשונה";
echo "</div>";
echo "<div class=\"fdata\" id=guest-first-".$guestSeq."></div>";

echo "</div>";
echo "<div class=\"lastMeal\">";
echo "<div class=\"title\">";
echo " מנה עיקרית";
echo "</div>";
echo "<div class=\"ldata\" id=guest-last-".$guestSeq."></div>";



echo "</div>";
echo "</div>";
echo "</div>";



echo "</div>";// end of main MenuOption





  
    $guestSeq++;
  
}
echo "</div>";//end of tab content
echo "<div class=\"mealBtn2\">";
echo "<a href=\"#\" onclick=\"makeOrder()\" class=\"BUTTON_HCW\">סיום</a>";
echo "</div>";
}

if($id=="order"){
$newOrder = json_decode($_POST["guest"]);
$eventId = $newOrder->eventId1;
$guestId = $newOrder->id;
$arrivalsMeals = $newOrder->arrivalList;
foreach($arrivalsMeals as $key=>$value){
    print "key=$key\n";
 
 
    foreach($value as $key1=>$value1){
        if($value1[0]!=0 && $value1[1]!=0){
       $sql = "INSERT INTO `selectedmeals`(`GuestID`, `EventId`, `GuestSeq`, `FirstMeal`, `LastMeal`) VALUES ($guestId, $eventId,$key,$value1[0],$value1[1]) ON DUPLICATE KEY UPDATE FirstMeal=$value1[0], LastMeal=$value1[1]";
  
        print "value1[0]=$value1[0]";
        print "value1[1]=$value1[1]";

        if(mysqli_query($con,$sql))
        {
          echo "success order";
          echo mysqli_error($con);
        
       
        }
        else
        {
          echo mysqli_error($con);
        
        }
    }
    
    }
    
    print "\n";
}
}

// Get user by name 
if($id=="byname"){
    $guestName=$_POST["guestName"];
    $eventid=$_POST["eventid"];
    $sql = "select * from guest where EventID=$eventid and FullName LIKE '%$guestName%' LIMIT 5";
    if($result = mysqli_query($con,$sql))
        {
            echo "<ul id='guestList'>";
                echo "<li>יש לבחור מהרשימה</li>";
   while($row = mysqli_fetch_assoc($result))
            {
                echo "<li class='sunny-morning-gradient' onclick='setGuestInfo({$eventid},{$row["NumberOfArrivals"]},{$row["id"]})'>".$row["FullName"]."</li>";
            }
            echo "</ul>";
        }
}

?>