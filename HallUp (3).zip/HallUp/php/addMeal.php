<?php
require "../Connection/connection.php";



if(isset($_POST["eventId"]) )
{
 // $sql = "INSERT INTO events ('HallID','Husband','Wife','Date','Phone') VALUES ('{$_POST["hallidc"]}','{$_POST["husbandc"]}','{$_POST["wifec"]}','{$_POST["datec"]}','{$_POST["phonec"]}')";
 
 
 $sql = "INSERT INTO `meals`(`CatID`, `EventId`, `Name`) VALUES ('{$_POST["mealcat"]}','{$_POST["eventId"]}','{$_POST["mname"]}')";

  if(mysqli_query($con,$sql))
  {
    http_response_code(201);
  
    echo "success";
  }
  else
  {
    echo mysqli_error($con);
  
  }
}