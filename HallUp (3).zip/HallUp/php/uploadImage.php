<?php
require "../Connection/connection.php";
/* Getting file name */
$filename = $_FILES['file']['name'];
echo $_POST["mealid"];

/* Location */
$location = "upload/".$filename;
$uploadOk = 1;
$imageFileType = pathinfo($location,PATHINFO_EXTENSION);

/* Valid Extensions */
$valid_extensions = array("jpg","jpeg","png");
/* Check file extension */
if( !in_array(strtolower($imageFileType),$valid_extensions) ) {
   $uploadOk = 0;
}

    $sql = "update meals set Pic='{$_FILES['file']['name']}' where MealID ='{$_POST["mealid"]}'";
    echo $sql;


    if(mysqli_query($con, $sql))
    {   echo "success path update";}
    else{
        echo "error while update path";
    }
    
if($uploadOk == 0){
   echo 0;
}else{
   /* Upload file */
   if(move_uploaded_file($_FILES['file']['tmp_name'],$location)){
      echo $location;
   }else{
      echo 0;
   }
}
?>