<?php
require "../Connection/connection.php";


// Get the posted data.


if(isset($_POST["husband"]) )
{



  // Update.
  $sql = "update events set Husband='".$_POST["husband"]."', wife='".$_POST["wife"]."', date='".$_POST["date"]."', phone='".$_POST["phone"]."' where EventID=".$_POST["evid"];

  if(mysqli_query($con, $sql))
  {
    http_response_code(204);
  }
  else
  {
    return http_response_code(422);
  }  
}