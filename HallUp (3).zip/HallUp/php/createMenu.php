<?php
require "../Connection/connection.php";



if(isset($_POST["menu"]) )
{
  $sql = "delete from eventmeals where EventID={$_POST["eventid"]}";
  mysqli_query($con,$sql);
  echo mysqli_error($con);
$menu = json_decode($_POST["menu"]);

foreach ($menu as $key => $val) {
    $catid=$key;
    foreach($val as $item){
      $sql = "insert into `eventmeals`(`EventID`, `MealID`, `CatID`) VALUES ('{$_POST["eventid"]}','{$item}','{$catid}')";
      if(mysqli_query($con,$sql))
      echo "Insert successful";
    }
    
  }
  echo mysqli_error($con);

}

// $sql = "insert into `eventmeals`(`EventID`, `MealID`, `CatID`) values ({},{},{})";





// {
//  $sql = "INSERT INTO events ('HallID','Husband','Wife','Date','Phone') VALUES ('{$_POST["hallidc"]}','{$_POST["husbandc"]}','{$_POST["wifec"]}','{$_POST["datec"]}','{$_POST["phonec"]}')";
 
//  $sql = "delete from eventsmeals where EventID={$_POST["eventid"]}";
 
//  $sql1 = "INSERT INTO `events`(`HallID`, `Husband`, `Wife`, `Date`, `Phone`) VALUES ('{$_POST["hallidc"]}','{$_POST["husbandc"]}','{$_POST["wifec"]}','{$_POST["datec"]}','{$_POST["phonec"]}')";



//   if(mysqli_query($con,$sql))
//   {
//     $sql1 = "INSERT INTO `events`(`HallID`, `Husband`, `Wife`, `Date`, `Phone`) VALUES ('{$_POST["hallidc"]}','{$_POST["husbandc"]}','{$_POST["wifec"]}','{$_POST["datec"]}','{$_POST["phonec"]}')";
//     if(mysqli_query($con,$sql))
//     {
//       echo "Created Menu";
//     }
//   }
//   else
//   {
//     echo mysqli_error($con);
  
//   }
// }
?>