<?php

function getTables(){

    $sql = "SELECT * FROM Tables where EventID=".$_SESSION["EventID"];
  
    if($result = mysqli_query($con,$sql))
    {
        echo "<select class=\"browser-default custom-select\">";
  
    
        while($row = mysqli_fetch_assoc($result))
        {
          echo "<option value='{$row[TableID]}'>{$row["Name"]}</option>";
  
    }
    echo " </select>";
  }
  }